#!/bin/sh

#
# You should run this script with root permission !
# You should upgrade RPi3 at first before running this script.
# sudo ./Install.sh
#

ME=`whoami`

if [ "$ME" != "root" ]; then
	echo "***********************************************************"
	echo " Notice: You should run this script with root permission ! "
	echo "***********************************************************"
	exit
fi

INST_PATH=/home/pi/2ston_cam

echo "Installing 2ston cam package..."

#
# Step-1 motion package installation
#
if [ ! -r /etc/motion/motion.conf ]; then
	apt-get install motion -y
else
	echo "Hmm, motion package has already been installed."
fi

#
# Step-2 2ston cam installation
#
if [ -d $INST_PATH ]; then
	echo ""
	echo "Hmm, 2ston_cam has already been installed."
	echo "Please uninstall it first if you want to reinstall it !"
else
	mkdir -p $INST_PATH
	mkdir -p $INST_PATH/tmp
	cp ./bin/* $INST_PATH
	chown -R pi:pi $INST_PATH

	cp ./bin/watch.sh /usr/bin
	cp ./bin/watch /usr/bin

	if [ ! -r /etc/motion/motion.conf.ORIG ]; then
		cp /etc/motion/motion.conf /etc/motion/motion.conf.ORIG
	fi
	cp ./cfg/motion.conf /etc/motion/motion.conf

	if [ ! -r /etc/default/motion.ORIG ]; then
		cp /etc/default/motion /etc/default/motion.ORIG
	fi
	cp ./cfg/motion /etc/default/motion

	if [ ! -r /etc/rc.local.ORIG ]; then
		cp /etc/rc.local /etc/rc.local.ORIG
	fi
	cp ./cfg/rc.local /etc/rc.local

	if [ ! -r /etc/crontab.ORIG ]; then
		cp /etc/crontab /etc/crontab.ORIG
	fi
	cp ./cfg/crontab /etc/crontab

	#install some libraries for zbar-0.1.0
	if [ ! -r /usr/local/lib/bzbar.so ]; then
		tar xvzf ./rpi3_lib.tar.gz
	fi

	echo
	while true; do
		read -p ">>> Do you want to set your nickname ?(y/n)" yn
		case $yn in
		[Yy]* ) vi $INST_PATH/NICKNAME; break;;
		[Nn]* ) break;;
			* ) echo "Please answer yes or no.";;
		esac
	done

	echo
	echo "OK, done."
	echo "You should reboot the system now to apply your installation."
fi
