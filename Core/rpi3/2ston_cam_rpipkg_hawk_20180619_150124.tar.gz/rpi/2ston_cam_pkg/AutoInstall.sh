#!/bin/sh

#
# Auto Installation Script 
# 2ston_otad(exactly, update.sh) will run this script. 
#

INST_PATH=/home/pi/2ston_cam

echo "Installing 2ston cam package..."

#
# 2ston cam installation
#
if [ -d $INST_PATH ]; then
	kill -9 `pidof watch` > /dev/null 2>&1
	kill -9 `pidof 2ston_cam` > /dev/null 2>&1

	sleep 2

	cp $INST_PATH/NICKNAME /tmp   #Let's backup the customer's nickname
	cp -f ./bin/* $INST_PATH
	cp /tmp/NICKNAME $INST_PATH   #Let's restore the customer's nickname
	chown -R pi:pi $INST_PATH

	cp ./bin/watch.sh /usr/bin
	cp ./bin/watch /usr/bin

	if [ ! -r /etc/motion/motion.conf.ORIG ]; then
		cp /etc/motion/motion.conf /etc/motion/motion.conf.ORIG
	fi
	cp ./cfg/motion.conf /etc/motion/motion.conf

	if [ ! -r /etc/default/motion.ORIG ]; then
		cp /etc/default/motion /etc/default/motion.ORIG
	fi
	cp ./cfg/motion /etc/default/motion

	if [ ! -r /etc/rc.local.ORIG ]; then
		cp /etc/rc.local /etc/rc.local.ORIG
	fi
	cp ./cfg/rc.local /etc/rc.local

	if [ ! -r /etc/crontab.ORIG ]; then
		cp /etc/crontab /etc/crontab.ORIG
	fi
	cp ./cfg/crontab /etc/crontab

	#install some libraries for zbar-0.1.0
	if [ ! -r /usr/local/lib/bzbar.so ]; then
		tar xzf ./rpi3_lib.tar.gz
	fi

	echo "OK, done."
	echo
	echo "The system will be rebooted after 5 seconds to apply your installation."
	sleep 5
	reboot
fi
