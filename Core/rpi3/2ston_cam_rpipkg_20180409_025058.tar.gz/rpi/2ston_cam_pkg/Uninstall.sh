#!/bin/sh

#
# You should run this script with root permission !
# sudo ./Uninstall.sh
#

echo "***********************************************************"
echo " Notice: You should run this script with root permission ! "
echo "***********************************************************"

INST_PATH=/home/pi/2ston_cam

echo "Uninstalling 2ston cam package ..."

#
# 2ston cam uninstallation
#
if [ -d $INST_PATH ]; then
	rm -rf $INST_PATH
	rm /usr/bin/watch
	rm /usr/bin/watch.sh

	if [ -r /etc/motion/motion.conf.ORIG ]; then
		mv /etc/motion/motion.conf.ORIG /etc/motion/motion.conf
	fi
	if [ -r /etc/default/motion.ORIG ]; then
		mv /etc/default/motion.ORIG /etc/default/motion
	fi
	if [ -r /etc/rc.local.ORIG ]; then
		mv /etc/rc.local.ORIG /etc/rc.local
	fi

	echo "OK, done."
	echo "You should reboot the system now to apply your installation."
else
	echo "Hmm, 2ston cam package is not installed."
fi

