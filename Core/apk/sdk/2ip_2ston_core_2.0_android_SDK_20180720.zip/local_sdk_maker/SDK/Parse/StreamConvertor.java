package com.a2ipco.stoncam.Parse;
import java.util.ArrayList;

/**
 * This Class for Parsing Byte Array data.
 * Created by Apolo on 2016...
 */
public class StreamConvertor {

    byte[] mBuffer;
    int mBufferSize;
    int mBufferIndex;

    public StreamConvertor(byte[] buffer, int size) {
        mBufferIndex = 0;
        mBuffer = buffer;
        mBufferSize = size;
    }

    /**
     * <PRE>
     * 패킷으로부터 일정 길이만큼 skip 하는 함수
     * @param len skip 길이정보
     * </PRE>
     */
    public void skip(int len) throws Exception {
        mBufferIndex += len;
    }

    /**
     * <PRE>
     * 패킷으로부터 byte 정보를 반환하는 함수
     * </PRE>
     */
    public byte getByte() throws Exception {
        if(mBufferIndex < 0 || mBufferIndex >= mBufferSize)
            throw new Exception("invalid index");

        return mBuffer[mBufferIndex++];
    }

    /**
     * <PRE>
     * 패킷으로부터 short 정보를 반환하는 함수
     * </PRE>
     */
    public short getShort() throws Exception {
        if(mBufferIndex < 0 || mBufferIndex >= mBufferSize)
            throw new Exception("invalid index");

        short retVal = 0;
        retVal |= mBuffer[mBufferIndex++] & 0x00FF;
        retVal |= (mBuffer[mBufferIndex++] << 8) & 0xFF00;
        return retVal;
    }

    /**
     * <PRE>
     * 패킷으로부터 int 정보를 반환하는 함수
     * </PRE>
     */
    public int getInt() throws Exception {
        if(mBufferIndex < 0 || mBufferIndex >= mBufferSize)
            throw new Exception("invalid index");

        int retVal = 0;
        retVal |= mBuffer[mBufferIndex++] & 0x000000FF;
        retVal |= (mBuffer[mBufferIndex++] << 8) & 0x0000FF00;
        retVal |= (mBuffer[mBufferIndex++] << 16) & 0x00FF0000;
        retVal |= (mBuffer[mBufferIndex++] << 24) & 0xFF000000;
        return retVal;
    }

    /**
     * <PRE>
     * 패킷으로부터 int 정보를 반환하는 함수
     * </PRE>
     */
    public int getInt(int bytes) throws Exception {
        if(mBufferIndex < 0 || mBufferIndex >= mBufferSize || bytes <= 0)
            throw new Exception("invalid index");

        int retVal = 0;

        retVal |= mBuffer[mBufferIndex++] & 0x000000FF;
        if(--bytes > 0)
            retVal |= (mBuffer[mBufferIndex++] << 8) & 0x0000FF00;
        if(--bytes > 0)
            retVal |= (mBuffer[mBufferIndex++] << 16) & 0x00FF0000;
        if(--bytes > 0)
            retVal |= (mBuffer[mBufferIndex++] << 24) & 0xFF000000;
        return retVal;
    }

    /**
     * <PRE>
     * 패킷으로부터 long 정보를 반환하는 함수
     * </PRE>
     */
    public long getLong() throws Exception {
        if(mBufferIndex < 0 || mBufferIndex >= mBufferSize)
            throw new Exception("invalid index");

        long retVal = 0L;
        retVal |= (mBuffer[mBufferIndex++] & 0xFF);
        retVal |= ((mBuffer[mBufferIndex++] & 0xFF) << 8);
        retVal |= ((mBuffer[mBufferIndex++] & 0xFF) << 16);
        retVal |= ((mBuffer[mBufferIndex++] & 0xFF) << 24);
        retVal |= ((mBuffer[mBufferIndex++] & 0xFF) << 32);
        retVal |= ((mBuffer[mBufferIndex++] & 0xFF) << 40);
        retVal |= ((mBuffer[mBufferIndex++] & 0xFF) << 48);
        retVal |= ((mBuffer[mBufferIndex++] & 0xFF) << 56);
        return retVal;
    }

    /**
     * <PRE>
     * 패킷으로부터 string 정보를 반환하는 함수
     * @param len string 길이정보
     * </PRE>
     */
    public String getString(int len) throws Exception {

        if(mBufferIndex >= mBufferSize || mBufferIndex + len > mBufferSize)
        {
            //return null;
            throw new Exception("invalid index");
        }
        if(mBufferIndex < 0 )
        {
            return null;
        }
        int data_len = 0;
        byte[] byteArray = new byte[len];

        boolean isEnd = false;
        for(int i=0; i<len; i++){
            byteArray[i] = mBuffer[mBufferIndex++];
            if(byteArray[i] == 0)
                isEnd = true;

            if(!isEnd)
                data_len++;
        }

        if(data_len > 0){
            return new String(byteArray, 0, data_len);
        }
        return null;
    }

    /**
     * <PRE>
     * 패킷으로부터 byte 정보를 반환하는 함수
     * @param len byte 길이정보
     * </PRE>
     */
    public byte[] getBytes(int len) throws Exception {
        if(mBufferIndex < 0 || mBufferIndex + len > mBufferSize)
            throw new Exception("invalid index");

        ArrayList<Byte> array = new ArrayList<Byte>();

        for(int i=0; i<len; i++){
            byte data = mBuffer[mBufferIndex++];
            if(data != 0)
                array.add(data);
        }

        byte[] byteArray = new byte[array.size()];
        for(int i=0; i<array.size(); i++) {
            byteArray[i] = array.get(i);
        }

        return byteArray;
    }

    /**
     * <PRE>
     * 패킷으로부터 byte 정보를 반환하는 함수
     * @param len byte 길이정보
     * </PRE>
     */
    public byte[] copy(int len) throws Exception {
        if(mBufferIndex < 0 || mBufferIndex + len > mBufferSize)
            throw new Exception("invalid index");

        byte[] byteArray = new byte[len];
        System.arraycopy(mBuffer, mBufferIndex, byteArray, 0, len);
        mBufferIndex += len;
        return byteArray;
    }
}
