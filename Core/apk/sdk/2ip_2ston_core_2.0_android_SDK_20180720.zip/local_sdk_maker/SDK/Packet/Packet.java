package com.a2ipco.stoncam.Utility;

/**
 * Created by thomas on 2018. 4. 11..
 */

public class Packet {
    public int index;
    public int event;
    public byte[] buffer;
    public int buffer_length;
}
