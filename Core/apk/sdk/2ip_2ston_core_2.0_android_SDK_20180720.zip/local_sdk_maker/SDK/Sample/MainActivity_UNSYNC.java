package twoip.t.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import twoip.core.twoston;


//비동기 함수 사용법.

public class MainActivity_UNSYNC extends AppCompatActivity {

    public static twoston ston;
    String _SERVER_IP = "2ipcamserver.ddns.net";
    int _SERVER_PORT = 25107;
    int _BUFFER_SIZE = 1024;

    Packet packet;
    StreamConvertor streamConvertor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ston = new twoston();

        ston.twoston_initialize(_SERVER_IP, _SERVER_PORT);

        Recv_Thread recv_thread = new Recv_Thread();
        recv_thread.start();

    }

    @Override
    protected void onStart() {
        super.onStart();

        ston.twoston_search_id("2ipcam103");

    }

    private class Recv_Thread extends Thread {
        @Override
        public void run() {
            super.run();

            packet = new Packet();
            int recv_result;
            int channel_index = 0;

            while (!Thread.currentThread().isInterrupted()) {
                packet.index = 0;
                packet.event = 0;
                packet.buffer = new byte[_BUFFER_SIZE];
                packet.buffer_length = _BUFFER_SIZE;

                recv_result = ston.twoston_recv(packet);
                streamConvertor = new StreamConvertor(packet.buffer, recv_result);

                switch (packet.event) {
                    case 23 : // search respond
                        try {
                            String ssn = streamConvertor.getString(64);
                            ston.twoston_pair(ssn);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;

                    case 25 : // Pair respond
                        try {
                            String identified_ssn = streamConvertor.getString(64);
                            channel_index = ston.twoston_channel_open(identified_ssn);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;

                    case 9 : //Channel open success
                        ston.twoston_holepunch_start(channel_index);
                        ston.twoston_sendto_Cfunc(channel_index, 31, null, 0);
                        break;
                }

            }
        }
    }
}
