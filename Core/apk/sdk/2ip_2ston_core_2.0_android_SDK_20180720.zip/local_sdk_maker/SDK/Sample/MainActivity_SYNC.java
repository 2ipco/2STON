package twoip.t.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import twoip.core.twoston;

//동기함수 사용법

public class MainActivity_SYNC extends AppCompatActivity {

    public static twoston ston;
    String _SERVER_IP = "2ipcamserver.ddns.net";
    int _SERVER_PORT = 25107;
    int _BUFFER_SIZE = 1024;

    Packet packet;
    StreamConvertor streamConvertor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ston = new twoston();

        ston.twoston_initialize(_SERVER_IP, _SERVER_PORT);

        Recv_Thread recv_thread = new Recv_Thread();
        recv_thread.start();

    }

    @Override
    protected void onStart() {
        super.onStart();
        int channel_index = 0;
        byte[] sync_buffer = new byte[256];
        String ssn = null;
        String identified_ssn = null;

        ston.twoston_search_id_sync("2ipcam103", sync_buffer, 256, 3);
        streamConvertor = new StreamConvertor(sync_buffer, 256);
        try {
            ssn = streamConvertor.getString(64);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ston.twoston_pair_sync(ssn, sync_buffer, 256, 3);
        streamConvertor = new StreamConvertor(sync_buffer, 256);
        try {
            identified_ssn = streamConvertor.getString(64);
        } catch (Exception e) {
            e.printStackTrace();
        }

        channel_index = ston.twoston_channel_open_sync(identified_ssn, null, 0, 3);
        ston.twoston_sendto_Cfunc(channel_index, 31, null, 0);
        ston.twoston_holepunch_start(channel_index);
    }

    private class Recv_Thread extends Thread {
        @Override
        public void run() {
            super.run();

            packet = new Packet();
            int recv_result;


            while (!Thread.currentThread().isInterrupted()) {
                packet.index = 0;
                packet.event = 0;
                packet.buffer = new byte[_BUFFER_SIZE];
                packet.buffer_length = _BUFFER_SIZE;

                recv_result = ston.twoston_recv(packet);
                streamConvertor = new StreamConvertor(packet.buffer, recv_result);

                switch (packet.event) {

                }

            }
        }
    }
}
