package com.a2ipco.stoncam.Parse;

/**
 * This Class for Parsing 2ip RPI Cam Streaming Data(Mjpeg)
 * Created by thomas on 2018. 4. 10..
 */

public class MjpegConvertor {

    final private String STREAM_REQUEST         ="GET / HTTP/1.1\r\nUser-Agent: curl/7.54.0\r\nAccept: */*\r\n\r\n";
    final private String STREAM_HTTP_START      = "HTTP/1.0";
    final private String STREAM_DEFAULT_BOUNDARY= "--BoundaryString\r\n";
    final private String STREAM_CONTENT_TYPE 	= "Content-type:";
    final private String STREAM_CONTENT_TYPE2   = "Content-Type:";
    final private String STREAM_CONTENT_LEGNTH 	= "Content-Length:";
    final private String STREAM_BOUNDARY_START 	= "boundary=";
    final private String HTTP_DELIMITER 		= "\r\n";
    final private String HTTP_HEADER_EOF 		="\r\n\r\n";

    private int in_boundary;
    private int image_size;
    private int frame_size;
    private byte[] image_file;
    private StringBuffer image_string_buffer;
    private int rest_bytes;
    private int count_frame;

    public MjpegConvertor() {
        in_boundary = 0;
        image_size = 0;
        frame_size = 0;
        image_file = null;
        image_string_buffer = new StringBuffer();
        rest_bytes = 0;
        count_frame = 0;
    }

    public byte[] MjpegStreamParse(byte[] data, int data_len) throws IndexOutOfBoundsException {
        String buffer = asciiBytesToString(data, data_len);
        count_frame++;

        if (data_len > 0)
        {
            int http_str_index_start = -1;
            int len_str_index_start = -1;
            int len_str_index_end = -1;
            http_str_index_start = buffer.indexOf(STREAM_HTTP_START); /* 맨 처음 시작 패킷 */
            len_str_index_start = buffer.indexOf(STREAM_CONTENT_LEGNTH); /* 실제 이미지 데이타가 시작되는 패킷 */
            len_str_index_end = buffer.indexOf("\r\n\r\n");

            if (len_str_index_start >= 0 && len_str_index_end >= 0) /* 새로운 이미지 */
            {
                if (image_size == frame_size && image_size > 0 && frame_size > 0)
                {
                    image_file = StringToAsciiBytes(image_string_buffer.toString(), image_size);
                    //Log.d("count_frame", "num="+count_frame);
                    count_frame = 0;
                    image_size = 0;
                    frame_size = 0;
                    rest_bytes = 0;
                }

                String len_str = buffer.substring(len_str_index_start + 15, len_str_index_end);
                len_str = len_str.replaceAll(" ", "");

                image_size = Integer.parseInt(len_str);
                frame_size = data_len - (len_str_index_end + 4);
                image_string_buffer.setLength(0);
                image_string_buffer.append(buffer, len_str_index_end + 4, data_len);

                return image_file;
            }
            else if (len_str_index_start < 0 && http_str_index_start < 0) /* 계속 되는 이미지 */
            {
                rest_bytes = image_size - frame_size; /* 파싱 시작할때 한 프레임의 남은 바이트를 구한다 */

                if (rest_bytes > 0) {
                    image_string_buffer.append(buffer, 0, data_len <= rest_bytes ? data_len : rest_bytes);
                    frame_size += (data_len <= rest_bytes ? data_len : rest_bytes);
                }
                return null;
            }
            else
            {
                return null;
            }
        }
        return null;
    }

    static public String asciiBytesToString(byte[] bytes, int length)
    {
        if ( (bytes == null) || (length == 0 ) )
        {
            return "";
        }

        char[] result = new char[length];

        for ( int i = 0; i < length; i++ )
        {
            result[i] = (char)bytes[i];
        }

        return new String( result );
    }

    static public byte[] StringToAsciiBytes(String str, int length)
    {
        if (str == null || length == 0) {
            return null;
        }

        byte[] dataset = new byte[length];

        for (int i = 0; i < length; ++i) {
            char c = str.charAt(i);
            dataset[i] = (byte)c;
        }
        return dataset;
    }
}


